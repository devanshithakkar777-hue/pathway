# Hackathon 2 – Claim Verification Pipeline (Pathway + TF-IDF)

## 📌 Overview
This project implements a **deterministic claim verification pipeline** that checks whether textual claims are supported by a given set of novels.  
The solution is **LLM-free**, fully **reproducible**, and built using **Pathway for data ingestion** and **TF-IDF + cosine similarity** for retrieval-based reasoning.

The pipeline processes novels, splits them into chunks, builds a TF-IDF index, and verifies claims from a test dataset by comparing them against the most relevant text chunks.

---

## 🧠 Key Characteristics
- ❌ **No LLMs used**
- ✅ **Deterministic & reproducible**
- ✅ **Pathway used for schema-driven ingestion**
- ✅ **Dockerized for judge execution**
- ✅ **Offline inference**
- ✅ **Results auto-generated as CSV**

---

## ⚙️ Methodology

### 1️⃣ Novel Ingestion (Pathway)
- Novels are split into overlapping word chunks.
- Each chunk is stored using a **Pathway schema**:
  - `book_id`
  - `chunk_id`
  - `start_word`
  - `end_word`
  - `text`

### 2️⃣ Index Construction
- TF-IDF vectors are built over all text chunks.
- Unigrams + bigrams are used.
- Stopwords removed.

### 3️⃣ Claim Processing
- Each claim is split into meaningful sentences.
- Each sentence is queried against the TF-IDF index.
- Top-K most similar chunks are retrieved.

### 4️⃣ Decision Logic
- If strong evidence from the expected book is found → **SUPPORT (1)**
- Otherwise → **CONTRADICTION / UNKNOWN (0)**

This approach ensures **transparent, explainable decisions** without any probabilistic black-box models.

---

## 🧪 How to Run (Judge Instructions)

### 🔹 Build Docker Image
```bash
docker build -t hackathon-pathway .

