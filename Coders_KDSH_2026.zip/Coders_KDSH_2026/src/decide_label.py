def decide_label(claim_results):
    """
    claim_results = list of True / False
    True = supported
    False = unsupported / contradict
    """
    if any(result is False for result in claim_results):
        return "contradict"
    return "consistent"
