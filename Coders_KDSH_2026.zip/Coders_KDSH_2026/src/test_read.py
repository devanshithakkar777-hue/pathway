# test_read.py

path = "../data/novels/The Count of Monte Cristo.txt"

with open(path, "r", encoding="utf-8") as f:
    text = f.read()

print("Total characters:", len(text))
print("First 500 characters:\n")
print(text[:500])
