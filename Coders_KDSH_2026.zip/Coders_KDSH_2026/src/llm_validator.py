import subprocess
import shutil


def validate_claim_with_llm(claim, evidence_chunks):
    """
    Uses Ollama (Mistral) to validate a claim against evidence.
    Returns one of: SUPPORTED, CONTRADICTED, NOT_MENTIONED
    """

    # ---------------- SAFETY CHECK ----------------
    # If Ollama is not available (e.g. inside Docker),
    # gracefully fallback instead of crashing
    if shutil.which("ollama") is None:
        return "NOT_MENTIONED"

    # ---------------- PREPARE EVIDENCE ----------------
    evidence_text = "\n\n".join(evidence_chunks[:3])

    prompt = f"""
You are validating a character backstory against a novel.

Claim:
"{claim}"

Evidence excerpts from the novel:
{evidence_text}

Task:
Decide whether the evidence SUPPORTS the claim, CONTRADICTS it,
or does NOT ADDRESS it.

Respond with exactly one word:
SUPPORTED
CONTRADICTED
NOT_MENTIONED
"""

    # ---------------- RUN LLM ----------------
    try:
        result = subprocess.run(
            ["ollama", "run", "mistral"],
            input=prompt,          # must be STRING
            capture_output=True,
            text=True,             # text mode
            encoding="utf-8",      # Windows safe
            errors="ignore",       # avoid decode crashes
            timeout=120
        )

        output = result.stdout.upper()

        for label in ("SUPPORTED", "CONTRADICTED", "NOT_MENTIONED"):
            if label in output:
                return label

        # fallback if LLM response is weird
        return "NOT_MENTIONED"

    except Exception as e:
        print("LLM error:", e)
        return "NOT_MENTIONED"
