# read_train.py
import pandas as pd

path = "../data/train.csv"

df = pd.read_csv(path)

print("Total rows:", len(df))
print("\nColumns:")
print(df.columns)

print("\nFirst row:")
print(df.iloc[0])
