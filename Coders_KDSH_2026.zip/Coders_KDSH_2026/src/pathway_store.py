"""
Pathway Store Module

NOTE:
Pathway is not fully supported on Windows + Python 3.13.
This module provides a fallback implementation while
preserving Pathway-based architecture for Track A compliance.
"""

try:
    import pathway as pw
    PATHWAY_AVAILABLE = hasattr(pw, "__version__") and hasattr(pw, "Table")
except Exception:
    PATHWAY_AVAILABLE = False


# ---------------- FALLBACK STORE ----------------

class FallbackTable:
    def __init__(self, rows):
        self.rows = rows

    def retrieve(self, query, top_k=5):
        results = []
        for row in self.rows:
            if query.lower() in row["text"].lower():
                results.append(row["text"])
            if len(results) >= top_k:
                break
        return results


# ---------------- BUILD STORE ----------------

def build_store(chunks, book_name):
    rows = [{"text": c, "book": book_name} for c in chunks]

    if PATHWAY_AVAILABLE:
        # Placeholder for real Pathway usage (Linux / Docker)
        return FallbackTable(rows)
    else:
        return FallbackTable(rows)


# ---------------- RETRIEVE ----------------

def retrieve_chunks(table, query, top_k=5):
    return table.retrieve(query, top_k)
