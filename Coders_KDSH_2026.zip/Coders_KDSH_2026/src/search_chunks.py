# search_chunks.py

# load chunks from chunk_novel.py logic

def chunk_text(text, chunk_size=1200, overlap=200):
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])
        start = end - overlap
    return chunks


# READ NOVEL
path = "../data/novels/In search of the castaways.txt"

with open(path, "r", encoding="utf-8") as f:
    text = f.read()

chunks = chunk_text(text)

print("Total chunks:", len(chunks))

# CLAIM KEYWORDS
claim_keywords = [
    ["colonist", "tribe", "native", "pampas"],
    ["track", "horses", "plains", "stars"]
]

# SEARCH
for idx, keywords in enumerate(claim_keywords, 1):
    print(f"\n--- Matches for Claim {idx} ---")
    count = 0
    for chunk in chunks:
        if any(word.lower() in chunk.lower() for word in keywords):
            print(chunk[:300], "\n---\n")
            count += 1
        if count == 2:
            break
