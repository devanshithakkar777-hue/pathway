# extract_claims.py
import pandas as pd

path = "../data/train.csv"
df = pd.read_csv(path)

# pick one example
row = df.iloc[0]

content = str(row["content"])
print("BACKSTORY:\n")
print(content)

print("\n--- CLAIMS ---")

# simple claim extraction: split by full stop
claims = [c.strip() for c in content.split(".") if len(c.strip()) > 20]

for i, claim in enumerate(claims, 1):
    print(f"{i}. {claim}")
