# chunk_novel.py

def chunk_text(text, chunk_size=1200, overlap=200):
    chunks = []
    start = 0

    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start = end - overlap

    return chunks


# --------- READ NOVEL ----------
path = "../data/novels/The Count of Monte Cristo.txt"

with open(path, "r", encoding="utf-8") as f:
    text = f.read()

print("Total characters:", len(text))

# --------- CHUNKING ----------
chunks = chunk_text(text)

print("Total chunks:", len(chunks))
print("\n--- First Chunk (500 chars) ---\n")
print(chunks[0][:500])
