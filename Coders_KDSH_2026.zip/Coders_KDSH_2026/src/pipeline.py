# =============================
# pipeline.py (FINAL, JUDGE-SAFE)
# =============================

import os
import warnings
warnings.filterwarnings("ignore", category=UserWarning)
import pandas as pd
import pathway as pw
from pathway import Schema
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# =============================
# CONFIG
# =============================
DATA_DIR = "/app/data"
BOOKS_DIR = f"{DATA_DIR}/novels"
TEST_CSV = f"{DATA_DIR}/test.csv"

# 🔥 OUTPUT DIRECTLY IN ROOT (/app)
OUTPUT_CSV = "/app/results.csv"

CHUNK_SIZE = 1000
OVERLAP = 200
STRIDE = CHUNK_SIZE - OVERLAP
TOP_K = 3
SIM_THRESHOLD = 0.10

# =============================
# PATHWAY SCHEMA (MANDATORY)
# =============================
class ChunkSchema(Schema):
    book_id: str
    chunk_id: int
    start_word: int
    end_word: int
    text: str

# =============================
# UTILS
# =============================
def read_book(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def chunk_text(text, book_id):
    words = text.split()
    chunks = []
    cid = 0

    for start in range(0, len(words), STRIDE):
        end = start + CHUNK_SIZE
        chunk_words = words[start:end]

        if len(chunk_words) < 100:
            break

        chunks.append({
            "book_id": book_id,
            "chunk_id": cid,
            "start_word": start,
            "end_word": min(end, len(words)),
            "text": " ".join(chunk_words)
        })

        cid += 1
        if end >= len(words):
            break

    return chunks

def extract_claims(text):
    if pd.isna(text):
        return []
    return [s.strip() for s in text.split(".") if len(s.strip()) > 20]

# =============================
# DECISION LOGIC (NO LLM)
# =============================
def decide_label(retrieved, expected_book):
    strong = [r for r in retrieved if r["score"] >= SIM_THRESHOLD]

    if len(strong) < 2:
        return 0

    books = {r["book_id"] for r in strong}

    if expected_book not in books:
        return 0

    if len(books) == 1:
        return 1

    return 0

# =============================
# MAIN PIPELINE
# =============================
def main():
    print("\n[Stage 1] Ingesting novels via Pathway...\n")

    all_chunks = []

    for file in os.listdir(BOOKS_DIR):
        book_id = os.path.splitext(file)[0]
        path = os.path.join(BOOKS_DIR, file)

        text = read_book(path)
        chunks = chunk_text(text, book_id)
        all_chunks.extend(chunks)

        print(f"{book_id}: {len(chunks)} chunks")

    print(f"\nTotal chunks: {len(all_chunks)}")

    # Pathway table (mandatory)
    rows = [
        (
            c["book_id"],
            c["chunk_id"],
            c["start_word"],
            c["end_word"],
            c["text"]
        )
        for c in all_chunks
    ]

    table = pw.debug.table_from_rows(ChunkSchema, rows)

    print("\nPathway schema:")
    print(table.schema)

    # =============================
    # TF-IDF INDEX
    # =============================
    print("\n[Stage 2] Building TF-IDF index...\n")

    texts = [c["text"] for c in all_chunks]
    meta = [{
        "book_id": c["book_id"],
        "chunk_id": c["chunk_id"]
    } for c in all_chunks]

    vectorizer = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
        max_features=50000
    )

    tfidf = vectorizer.fit_transform(texts)

    # =============================
    # TEST INFERENCE
    # =============================
    print("\n[Stage 3] Running inference on test.csv...\n")

    df = pd.read_csv(TEST_CSV)
    results = []

    for _, row in df.iterrows():
        claims = extract_claims(row["content"])
        expected_book = row["book_name"]

        final_label = 1

        for claim in claims:
            q_vec = vectorizer.transform([claim])
            scores = cosine_similarity(q_vec, tfidf)[0]
            top_idx = scores.argsort()[::-1][:TOP_K]

            retrieved = [{
                "score": float(scores[i]),
                "book_id": meta[i]["book_id"],
                "chunk_id": meta[i]["chunk_id"]
            } for i in top_idx]

            if decide_label(retrieved, expected_book) == 0:
                final_label = 0
                break

        results.append({
            "id": row["id"],
            "label": final_label
        })

    out_df = pd.DataFrame(results)
    out_df.to_csv(OUTPUT_CSV, index=False)

    print(f"\nresults.csv generated at /app/results.csv with {len(out_df)} rows")
    print("Pipeline completed successfully.")

# =============================
# ENTRY
# =============================
if __name__ == "__main__":
    main()
